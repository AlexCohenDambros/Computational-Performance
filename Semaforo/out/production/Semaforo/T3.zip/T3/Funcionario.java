package T3;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class Funcionario extends Thread{
	public String nome;
	public char empresa;
	public Semaphore sEmpresaA;
	public Semaphore sEmpresaB;
	public Semaphore sNFuncionarios;
	public Semaphore sEmpresaAtual;
	private Random rand;
	public CSC csc;

	public Funcionario(String nome, char empresa, Semaphore sEmpresaA, Semaphore sEmpresaB, Semaphore sNFuncionarios, Semaphore sEmpresaAtual, CSC csc) {
		this.nome = nome;
		this.empresa = empresa;
		this.sEmpresaA = sEmpresaA;
		this.sEmpresaB = sEmpresaB;
		this.sNFuncionarios = sNFuncionarios;
		this.sEmpresaAtual = sEmpresaAtual;
		this.rand = new Random();
		this.csc = csc;
	}

	@Override
	public void run(){
		try {
			Thread.sleep(rand.nextInt(10_000));

			sNFuncionarios.acquire();
			if(csc.getnFuncionarios() == 0){
				if(empresa == 'A'){
					sEmpresaB.acquire(3);
					csc.setEmpresaAtual('A');
					sEmpresaA.acquire();
				} else{
					sEmpresaA.acquire(3);
					csc.setEmpresaAtual('B');
					sEmpresaB.acquire();
				}
				System.out.println(nome+" ["+empresa+"] tentando acesso");
				csc.setnFuncionarios(csc.getnFuncionarios()+1);
				sNFuncionarios.release();
			}else{
				if(csc.getEmpresaAtual() == empresa){
					sNFuncionarios.release();
					System.out.println(nome+" ["+empresa+"] tentando acesso");
					if(empresa == 'A'){
						sEmpresaA.acquire();
					}else{
						sEmpresaB.acquire();
					}
					csc.setnFuncionarios(csc.getnFuncionarios()+1);
				}else{
					sNFuncionarios.release();
					if(empresa == 'A'){
						System.out.println(nome+" ["+empresa+"] tentando acesso");
						sEmpresaA.acquire();
					}else{
						System.out.println(nome+" ["+empresa+"] tentando acesso");
						sEmpresaB.acquire();
					}
				}
			}


			System.out.println("+ "+nome+" ["+empresa+"] acessou");
			csc.rodar();
			System.out.println("- "+nome+" ["+empresa+"] terminou acesso");

			if(empresa == 'A'){
				sEmpresaA.release();
			}else{
				sEmpresaB.release();
			}
			csc.setnFuncionarios(csc.getnFuncionarios()-1);

			sNFuncionarios.acquire();
			if(csc.getnFuncionarios() == 0){
				if(empresa == 'A'){
					sEmpresaB.release(3);
				}else{
					sEmpresaA.release(3);
				}
			}
			sNFuncionarios.release();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
